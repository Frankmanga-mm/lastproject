<?php
// db_config.php - Database configuration
$servername = "localhost";
$username = "root";
$password = "immamlelwa";
$dbname = "timetable";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch courses from the 'courses' table
$sql = "SELECT DISTINCT level FROM courses";
$result = $conn->query($sql);

// Check if there are results
if ($result->num_rows > 0) {
    $courses = array();

    // Fetch and store each course
    while ($row = $result->fetch_assoc()) {
        $courses[] = $row['level'];
    }

    // Close the connection
    $conn->close();

    // Return courses as JSON
    echo json_encode($courses);
} else {
    // No courses found
    echo "No courses found";
}

?>
